% [r0,v0]=EIF0M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs)
%
% Matlab version of EIF0.c  
% The C version is faster.
%
% Computes the steady state firing rate, r0, and mean membrane potential,
%  v0, of an EIF model neuron driven by additive noise.
%   
%  Neuron model is assumed to obey:
%    Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)+muI+sqrt(2*DI)*eta
%  where eta is Gaussian white noise.
%  When V reaches threshold at Vth, it is reset instantly to Vre.
%  
%  The membrane potential mesh is passed in the array, vs.
%  The last element of vs is assumed to be Vth and the first 
%  element (Vlb) should be small enough that 
%  the density is approximately zero there. A warning will be
%  issued if the density is not small at Vlb.
%
%
% Uses threshold integration methods from:
%  
% Richardson, M.J.E. (2008). Spike-train spectra and network response 
% functions for non-linear integrate-and-fire neurons. Biological 
% Cybernetics, 99(4-5), 381-92.
% 
% with the modifications and extensions described in:
% 
% Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
% neuron models with stochastic inputs.  To appear.
%  
% Please cite these papers if you publish research that uses this code or some modification
% thereof.
%
% Author: Robert Rosenbaum
%

function [r0,v0]=EIF0M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs)

Nv=numel(vs);

% Initialize stuff 
p0=0; % value of density, p0 
p0last=0; % value of density on previous mesh element 
p0int=0; % running estimate of integral of p0 
v0=0; % running estimate of integral of p0*v, which gives mean v 
D=(DI)/(Cm*Cm); % Diffusion coeff is constant 

% Iterate backward through mesh, starting at the second-to-last element 
for k=(Nv-1):-1:1
    
    vleft=vs(k); % left endpoint of mesh 
    vright=vs(k+1); % right endpoint of mesh 
    vmid=(vleft+vright)/2; % potential at midpoint of mesh 
    dv=vright-vleft; % Current mesh step 
    
    
    % Check to make sure mesh is increasing 
    if(dv<=0)
       error('dv negative or zero.');
    end
    
    %* Simpson's rule for G *
    
      % Evaluate G and H at left endpoint 
      Gleft=-(-gL*(vleft-EL)+gL*DeltaT*exp((vleft-VT)/DeltaT)+muI)/(D*Cm);
      
      % Evaluate G and H at midpoint 
      Gmid=-(-gL*(vmid-EL)+gL*DeltaT*exp((vmid-VT)/DeltaT)+muI)/(D*Cm);
 
      % Evaluate G and H at right endpoint 
      Gright=-(-gL*(vright-EL)+gL*DeltaT*exp((vright-VT)/DeltaT)+muI)/(D*Cm);
      
      % Estimate the integral of G 
      % over entire interval 
      Gint=(1.0/6.0)*(Gleft+4*Gmid+Gright)*dv;

      % Just evaluate H at midpoint 
      H=(vmid>Vre)*(1/D);
      
     % Evaluate G halfway between left enpoint and midpoint 
     % For use in the line below 
      vmidmid=vmid-dv/2.0;
      Gmidmid=-(-gL*(vmidmid-EL)+gL*DeltaT*exp((vmidmid-VT)/DeltaT)+muI)/(D*Cm);
      
      % Now estimate the integral of G from the left endpoint to the midpoint 
      Gint2=(1.0/6.0)*(Gleft+4*Gmidmid+Gmid)*(vmid-vleft);
      
      % Estimate the integral of 
      % H*exp(Int G) over entire interval      
      HexpIntG=(1.0/6.0)*H*(1+4*exp(Gint2)+exp(Gint))*dv;
      
      % update p0 
      p0=p0*exp(Gint)+HexpIntG;
      
    % Trapezoidal approximation to integral 
    p0int=p0int+dv*((p0+p0last)/2.0);
    v0=v0+dv*((p0*vleft+p0last*(vright))/2.0);    
    p0last=p0;

end

% A quick and dirty check to make sure that the density is nearly 
%   zero at the first element of vs.  Just see if it's sufficiently
%   smaller than the mean value of p0 
if(p0/(p0int/(vs(Nv)-vs(1)))>0.001)
     warning('Warning: density at lower bound might not be small enough.');
     disp(sprintf('\nRatio=%f\n',p0/(p0int/(vs(Nv-1)-vs(1)))));
end

% Variables to return 
r0=1/(p0int);   % rate is 1/(integral of p0) 
v0=v0*r0; % membrane potential is (integral of p0*v)*rate 


end

