/* 
[Sr,Sv]=EIF1(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs,freqs,p0);

 Computes the linear response of the firing rate, r1, and the mean
 membrane potential, v1 of an EIF model neuron driven by additive noise.
  
 Neuron model is assumed to obey:
   Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)+muI+sqrt(2*DI)*eta+perturbation
 where eta is Gaussian white noise.
 When V reaches threshold at Vth, it is reset instantly to Vre.
 Uses Modified Euler Method from:
 
 freqs is a vector of frequencies over which the linear response is computed.
 All frequencies are interpreted with units kHz. 
 Frequency vectors should be positive and monotonically increasing.
 
 Richardson, M.J.E. (2008). Spike-train spectra and network response 
 functions for non-linear integrate-and-fire neurons. Biological 
 Cybernetics, 99(4-5), 381-92.
 
 Except that integrals are computed using Simpson's rule instead of the
 midpoint rule used there.
 
 The membrane potential mesh is passed in the array, vs.
 The last element of vs is assumed to be Vth and the first 
 element (Vlb) should be small enough that 
 the density is approximately zero there. A warning will be
 issued if the density is not small at Vlb.

 The steady state density, p0, should also be passed in.  It should
 be the same length as vs.
 
Uses threshold integration methods from:
 
Richardson, M.J.E. (2008). Spike-train spectra and network response 
functions for non-linear integrate-and-fire neurons. Biological 
Cybernetics, 99(4-5), 381-92.

with the modifications and extensions described in:

Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
neuron models with stochastic inputs.  To appear.
 
Please cite these papers if you publish research that uses this code or some modification
thereof.

Author: Robert Rosenbaum
*/


#include "mex.h"
#include "math.h"
#include <complex>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

int i,m,n,k,m1,m2,Nv,flag,Mfreqs,Nfreqs,numfreqs;
double muI,DI,Cm,gL,VT,Vre,EL,DeltaT,*vs,*p0,dv,G,H,j0,p0int,*SrReal,*SrImag,*SvReal,*SvImag,p00;
double expGint,expGint2,v,Gleft,Gright,Gmid,Gmidmid;
double A0,dA0dv,D0,*freqs;
std::complex<double> A1,p1,pr,j1,jr,p1vint,prvint,p1last,prlast,H1left,H1right,H1mid,Hrleft,Hrmid,Hrright,HrexpIntG,H1expIntG;
std::complex<double> I (0.0,1.0);
double pi=3.14159265359;

/* get inputs */
muI=mxGetScalar(prhs[0]);
DI=mxGetScalar(prhs[1]);
Cm=mxGetScalar(prhs[2]);
gL=mxGetScalar(prhs[3]);
VT=mxGetScalar(prhs[4]);
Vre=mxGetScalar(prhs[5]);
EL=mxGetScalar(prhs[6]);
DeltaT=mxGetScalar(prhs[7]);
vs=mxGetPr(prhs[8]);
Nv = mxGetM(prhs[8]);
m1 = mxGetN(prhs[8]);
if(Nv==1 && m1!=1){
    Nv=m1;
    m1=1;
}
if(Nv<=1||m1!=1)
    mexErrMsgTxt("vs must be Nvx1 or 1xNv.");
freqs=mxGetPr(prhs[9]);
Mfreqs = mxGetM(prhs[9]);
Nfreqs = mxGetN(prhs[9]);
numfreqs=Mfreqs*Nfreqs;
p0=mxGetPr(prhs[10]);
m1 = mxGetM(prhs[10]);
m2 = mxGetN(prhs[10]);
if(!((m1==1&&m2==Nv)||(m1==Nv&&m2==1)))
    mexErrMsgTxt("p0 must be same length as vs.");
  

/* Allocate outputs */
plhs[0]=mxCreateDoubleMatrix(Mfreqs, Nfreqs, mxCOMPLEX);
SrReal=mxGetPr(plhs[0]);
SrImag=mxGetPi(plhs[0]);

plhs[1]=mxCreateDoubleMatrix(Mfreqs, Nfreqs, mxCOMPLEX);
SvReal=mxGetPr(plhs[1]);
SvImag=mxGetPi(plhs[1]);

/* Perform threshold integration at each frequency */
/* The EIF0.c code is better commented and very similar */
/* to this code.  See there for more clarification. */
D0=(DI)/(Cm*Cm);
for(i=0;i<numfreqs;i++){
    p1=0;
    pr=0;
    p1last=p1;
    prlast=pr;
    j1=0;
    jr=1;
    p1vint=0;
    prvint=0;
    flag=0;
    for(k=Nv-2;k>=0;k--){

        dv=vs[k+1]-vs[k];
        if(dv<=0)
           mexErrMsgTxt("dv negative or too small.");

        /* Evaluate G, H1 and Hr and left endpoint */
        v=vs[k];    
        p00=p0[k];
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        dA0dv=(-gL+gL*exp((v-VT)/DeltaT))/Cm;        
        A1=(1)/Cm;        
        Gleft=-A0/D0;
        H1left=(j1-A1*p00)/D0; 
        Hrleft=jr/D0;

        /* Evaluate G, H1 and Hr and midpoint */
        v=(vs[k]+vs[k+1])/2.0;
        p00=(p0[k]+p0[k+1])/2.0;
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        dA0dv=(-gL+gL*exp((v-VT)/DeltaT))/Cm;        
        A1=(1)/Cm;        
        Gmid=-A0/D0;
        H1mid=(j1-A1*p00)/D0; 
        Hrmid=jr/D0; 

        /* Evaluate G, H1 and Hr and right endpoint */
        v=vs[k+1];
        p00=p0[k+1];
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        dA0dv=(-gL+gL*exp((v-VT)/DeltaT))/Cm;        
        A1=(1)/Cm;        
        Gright=-A0/D0;
        H1right=(j1-A1*p00)/D0; 
        Hrright=jr/D0;

        /* Simspon's approx to exponential of integral of G */
        expGint=exp((1.0/6.0)*(Gleft+4*Gmid+Gright)*dv);

        /* Evaluate G halfway between left enpoint and midpoint */
        /* For use in the line below */
        v=(vs[k+1]+3.0*vs[k])/4.0;
        p00=(p0[k+1]+3.0*p0[k+1])/4.0;
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        dA0dv=(-gL+gL*exp((v-VT)/DeltaT))/Cm;        
        A1=(1)/Cm;        
        Gmidmid=-A0/D0;       

        /* Now estimate the integral of G from the left endpoint to the midpoint */
        expGint2=exp((1.0/6.0)*(Gleft+4.0*Gmidmid+Gmid)*(dv/2.0));

        /* Estimate the integral of 
         H*exp(Int G) over entire interval */
         H1expIntG=(1.0/6.0)*(H1left*1.0+4.0*H1mid*(double)expGint2+H1right*(double)expGint)*dv;
         HrexpIntG=(1.0/6.0)*(Hrleft*1.0+4.0*Hrmid*(double)expGint2+Hrright*(double)expGint)*dv;

         p1=p1*expGint+H1expIntG;
         pr=pr*expGint+HrexpIntG;

        j1+=2*pi*I*freqs[i]*p1*dv;
        jr+=2*pi*I*freqs[i]*pr*dv;

        if(flag==0 && v<=Vre){
            jr-=1;
            flag=1; 
           }

        /* Trapezoidal approx to integral */
        p1vint+=((p1+p1last)/2.0)*v*dv;
        prvint+=((pr+prlast)/2.0)*v*dv;

        p1last=p1;
        prlast=pr;

        }
    SrReal[i]=real(-j1/jr);
    SrImag[i]=imag(-j1/jr);
    SvReal[i]=real(p1vint+(SrReal[i]+I*SrImag[i])*prvint);
    SvImag[i]=imag(p1vint+(SrReal[i]+I*SrImag[i])*prvint);
}




}

