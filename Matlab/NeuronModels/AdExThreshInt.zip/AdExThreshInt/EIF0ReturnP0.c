/* 
[r0,v0,P0]=EIF0ReturnP0(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs);
 
 Computes the steady state firing rate, r0, and mean membrane potential,
 v0, and steady-state density, P0, of an EIF model neuron driven by additive noise.
  
 Neuron model is assumed to obey:
   Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)+muI+sqrt(2*DI)*eta
 where eta is Gaussian white noise.
 When V reaches threshold at Vth, it is reset instantly to Vre.

 The membrane potential mesh is passed in the array, vs.
 The last element of vs is assumed to be Vth and the first 
 element (Vlb) should be small enough that 
 the density is approximately zero there. A warning will be
 issued if the density is not small at Vlb.
 
Uses threshold integration methods from:
 
Richardson, M.J.E. (2008). Spike-train spectra and network response 
functions for non-linear integrate-and-fire neurons. Biological 
Cybernetics, 99(4-5), 381-92.
 
with the modifications and extensions described in:

Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
neuron models with stochastic inputs.  To appear.
 
Please cite these papers if you publish research that uses this code or some modification
thereof.

Author: Robert Rosenbaum

 */


#include "mex.h"
#include "math.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

int i,m,n,k,m1,m2,Nv;
double A,D,muI,DI,Cm,gL,VT,Vre,Vlb,EL,DeltaT,*vs,*r0,*p0,dv,Gint,H,j0,p0int,*v0,vmid,Gleft,Gright,Gmid,vmidmid,Hleft,Hright,Hmid,Gmidmid,Gint2,HexpIntG;

/* get inputs from Matlab */
muI=mxGetScalar(prhs[0]);
DI=mxGetScalar(prhs[1]);
Cm=mxGetScalar(prhs[2]);
gL=mxGetScalar(prhs[3]);
VT=mxGetScalar(prhs[4]);
Vre=mxGetScalar(prhs[5]);
EL=mxGetScalar(prhs[6]);
DeltaT=mxGetScalar(prhs[7]);
vs=mxGetPr(prhs[8]);
Nv = mxGetM(prhs[8]);
m1 = mxGetN(prhs[8]);
if(Nv==1 && m1!=1){
    Nv=m1;
    m1=1;
}
if(Nv<=1||m1!=1)
    mexErrMsgTxt("vs must be Nvx1 or 1xNv.");


/* allocate outputs */
plhs[0]=mxCreateDoubleMatrix(1, 1, mxREAL);
r0=mxGetPr(plhs[0]);
plhs[1]=mxCreateDoubleMatrix(1, 1, mxREAL);
v0=mxGetPr(plhs[1]);
plhs[2]=mxCreateDoubleMatrix(1, Nv, mxREAL);
p0=mxGetPr(plhs[2]);



/* Initialize stuff */
p0[Nv-1]=0; /* value of density, p0 at threshold */
j0=1; /* value of flux */
p0int=0; /* running estimate of integral of p0 */
v0[0]=0; /* running estimate of integral of p0*v, which gives mean v */
D=(DI)/(Cm*Cm); /* Diffusion coeff is constant */

/* Iterate backward through mesh, starting at the second-to-last element */
for(k=Nv-2;k>=0;k--){
    
    dv=vs[k+1]-vs[k]; /* Current mesh step */
    vmid=(vs[k]+vs[k+1])/2; /* potential at midpoint of mesh */
    
    /* Check to make sure mesh is increasing */
    if(dv<=0)
       mexErrMsgTxt("dv negative or too small.");

    
    /** Simpson's rule for G and H **/
    
      /* Evaluate G and H at left endpoint */
      Gleft=-(-gL*(vs[k]-EL)+gL*DeltaT*exp((vs[k]-VT)/DeltaT)+muI)/(D*Cm);
      Hleft=(vs[k]>Vre)*(1/D);
      
      /* Evaluate G and H at midpoint */
      Gmid=-(-gL*(vmid-EL)+gL*DeltaT*exp((vmid-VT)/DeltaT)+muI)/(D*Cm);
      Hmid=(vmid>Vre)*(1/D);
 
      /* Evaluate G and H at right endpoint */
      Gright=-(-gL*(vs[k+1]-EL)+gL*DeltaT*exp((vs[k+1]-VT)/DeltaT)+muI)/(D*Cm);
      Hright=(vs[k+1]>Vre)*(1/D);      
      
      /* Estimate the integral of G */
      /* over entire interval */
      Gint=(1.0/6.0)*(Gleft+4*Gmid+Gright)*dv;

      
     /* Evaluate G halfway between left enpoint and midpoint */
     /* For use in the line below */
      vmidmid=vmid-dv/2.0;
      Gmidmid=-(-gL*(vmidmid-EL)+gL*DeltaT*exp((vmidmid-VT)/DeltaT)+muI)/(D*Cm);
      
      /* Now estimate the integral of G from the left endpoint to the midpoint */
      Gint2=(1.0/6.0)*(Gleft+4*Gmidmid+Gmid)*(vmid-vs[k]);
      
      /* Estimate the integral of 
         H*exp(Int G) over entire interval */     
      HexpIntG=(1.0/6.0)*(Hleft*1+4*Hmid*exp(Gint2)+Hright*exp(Gint))*dv;
      
      /* update p0 */
      p0[k]=p0[k+1]*exp(Gint)+HexpIntG;
      
    /* Trapezoidal approximation to integral */
    p0int+=dv*((p0[k]+p0[k+1])/2.0);
    v0[0]+=dv*((p0[k]*vs[k]+p0[k+1]*(vs[k+1]))/2.0);    
    

}

/* A quick and dirty check to make sure that the density is nearly 
   zero at the first element of vs.  Just see if it's sufficiently
   smaller than the mean value of p0 */
if(p0[0]/(p0int/(vs[Nv-1]-vs[0]))>0.001)
     mexWarnMsgTxt("Warning: density at lower bound might not be small enough.");

/* Variables to return */
r0[0]=1/(p0int);   /* rate is 1/(integral of p0) */
v0[0]=v0[0]*r0[0]; /* membrane potential is (integral of p0*v)*rate */

/* Re-normalize p0 */
for(k=Nv-2;k>=0;k--)
    p0[k]=p0[k]/p0int;


}
