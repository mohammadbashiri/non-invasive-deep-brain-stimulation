
% Neuron parameters
taum=15;
Cm=1;
gL=Cm/taum;
EL=-72;
DeltaT=1;
VT=-55;
Vth=-45;
Vre=-72;
tauw=50;
Vlb=-100;
a=.15;
b=.025;

% Membrane potential mesh for threhold integration solver
dv0=.1;
vs=[Vlb:dv0:(Vre-dv0) Vre-dv0/2 Vre Vre+dv0/2 (Vre+dv0):dv0:(VT-dv0) (VT-dv0/2):(dv0/2):(Vth-dv0/2) Vth];

% Synaptic weights 
Je=.4;
Ji=-.75;

% Input rates (in kHz)
re=10;
ri=2;
