----------
Threshold integration methods for the adaptive exponential integrate and fire (AdEx) 
neuron model driven by noisy current-based (i.e., additive) input.

Author: Robert Rosenbaum

A suite or programs to approximate steady-state statistics and linear response functions 
for the AdEx model defined by the Langevin equations

   Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)-w+muI+sqrt(2*DI)*eta
 tauw*w'=-w+a*(V-EL)

with the added condition that V is reset to Vre whenever it reaches Vth.

Uses threshold integration methods from:
 
Richardson, M.J.E. (2008). Spike-train spectra and network response 
functions for non-linear integrate-and-fire neurons. Biological 
Cybernetics, 99(4-5), 381-92.

and fixed point iteration methods from:
 
Richardson, M. (2009). Dynamics of populations and networks of neurons with 
voltage-activated and calcium-activated currents. Physical Review E, 80(2), 021928. 
 
with the modifications and extensions described in:

Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
neuron models with stochastic inputs.  To appear.
 
Please cite these papers if you publish research that uses this code or some modification
thereof.
 
See that manuscript and the comments within each function for more information on the
implementation and how to call the functions. 
 
----------

Instructions for using slower, Matlab implementations of treshold-integrator:

The files EIF0M.m, EIF0ReturnP0M.m, EIF1M.m, AdEx0M.m and AdEx1M.m use Matlab routines 
only and should be ready to use in Matlab.  See comments at top for instructions on use.

For sample code that calls these functions, see the scripts Figure1M.m and Figure8M.m
which generate the numerical results from figures 1 and 8 of (Rosenbaum, 2016).

These scripts should be usable right out of the box.


----------

Instructions for using faster, C, implementations:

The files AdEx0.m and AdEx1.m call C programs that must be compiled from within
Matlab using the "mex" command before they can be run.

Note that they only need to be compiled once per computer that they are being run on.  
You DO NOT need to compile them every time you call the functions.  

To compile, run these commands in the Matlab command line:
mex EIF0.c
mex EIF0ReturnP0.c
mex EIF1.c

Your compiler might complain about the complex data type used in EIF1.c.  If so, use the
cpp version instead by calling:
mex EIF1.cpp

For sample code that calls these functions, see the scripts Figure1.m and Figure8.m
which generate the numerical results from figures 1 and 8 of (Rosenbaum, 2016).

---------

The function names that start with "EIF" perform threshold integration for
the non-adaptive EIF model.  They can be used on their own if you are considering 
a non-adaptive model or just call the AdEx solvers with a=0 and b=0.

E-mail Robert.Rosenbaum@nd.edu with any questions, bugs or improvements you've made 
to the code.  I am happy to help with any issues related to the implementation of 
the solvers.  If you are having trouble getting mex to work on your computer, I will
not be of much use.  Use online resources to figure out how to get your mex compiler 
working or switch to the Matlab versions of the code.

