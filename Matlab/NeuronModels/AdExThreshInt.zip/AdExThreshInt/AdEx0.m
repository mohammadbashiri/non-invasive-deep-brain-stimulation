%
% [r0,v0,P0]=AdEx0(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs)
% Computes the steady state firing rate, r0, and mean membrane potential,
%  v0, of an AdEx model neuron driven by additive noise.
% Optionally returns steady state density, P0.
%   
%  Neuron model is assumed to obey:
%    Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)-w+muI+sqrt(2*DI)*eta
%  tauw*w'=-w+a*(V-EL)
%  where eta is Gaussian white noise.
%  When V reaches threshold at Vth, it is reset instantly to Vre
%  and w is incremented by b.
%
%  The membrane potential mesh is passed in the array, vs.
%  The last element of vs is assumed to be Vth and the first 
%  element (Vlb) should be small enough that 
%  the density is approximately zero there. A warning will be
%  issued if the density is not small at Vlb.
%
% Uses threshold integration methods from:
%  
% Richardson, M.J.E. (2008). Spike-train spectra and network response 
% functions for non-linear integrate-and-fire neurons. Biological 
% Cybernetics, 99(4-5), 381-92.
% 
% and fixed point iteration methods from:
%  
% Richardson, M. (2009). Dynamics of populations and networks of neurons with 
% voltage-activated and calcium-activated currents. Physical Review E, 80(2), 021928. 
% doi:10.1103/PhysRevE.80.021928
%  
% with the modifications and extensions described in:
% 
% Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
% neuron models with stochastic inputs.  To appear.
%  
% Please cite these papers if you publish research that uses this code or some modification
% thereof.
%
% Author: Robert Rosenbaum
%


function [r0,v0,P0]=AdEx0(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs)

% Min number of iterations
mini=2;

% Relative error tolerance for fixed point convergence
tol=.0001;

% If a and b are zero, just return EIF rate, mean v
if(abs(a)<=1e-10 && abs(b)<=1e-10)
    [r0,v0]=EIF0(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs);
    if(nargout==3)
       [r0,v0,P0]=EIF0ReturnP0(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs); 
    end
    return;
end

% di is the iteration step size.
% Larger di may not converge, but converged
% quickly when it does.
% Smaller di is more likely to converge, but
% does so more slowly.
% maxi is the number of iterative steps before
% giving up.
% First try large steps
di=.25;
maxi=50;
nubefore=Inf;
v0before=Inf;
r0=0;
v0=0;
w0=0;
i=0;
while((~(abs((nubefore-r0)/(nubefore+1e-15))+abs((v0before-v0)/(v0before+1e-15))<tol) && i<maxi)||i<mini)
   nubefore=r0;
   v0before=v0;   
   [tempnu,tempv]=EIF0(muI-w0,DI,Cm,gL,VT,Vre,EL,DeltaT,vs);
   r0=tempnu;
   v0=tempv;
   w0=(1-di)*w0+di*(a*(v0-EL)+b*r0*tauw);    
   i=i+1;   
end

% If that didn't work, try smaller steps
if(i>=maxi)
    di=.1;
    maxi=100;
    nubefore=Inf;
    v0before=Inf;
    r0=0;
    v0=0;
    w0=0;
    i=0;
    while((~(abs((nubefore-r0)/(nubefore+1e-15))+abs((v0before-v0)/(v0before+1e-15))<tol) && i<maxi)||i<mini)
       nubefore=r0;
       v0before=v0;   
       [r0,v0]=EIF0(muI-w0,DI,Cm,gL,VT,Vre,EL,DeltaT,vs);
       w0=(1-di)*w0+di*(a*(v0-EL)+b*r0*tauw);    
       i=i+1;   
    end  
end


% If that didn't work, try much smaller steps and issue warning
if(i>=maxi)
    warning('Bad convergence for AdEx fixed point iterator.  Might be slow.')
    di=.01;
    maxi=10000;
    nubefore=Inf;
    v0before=Inf;
    r0=0;
    v0=0;
    w0=0;
    i=0;
    while((~(abs((nubefore-r0)/(nubefore+1e-15))+abs((v0before-v0)/(v0before+1e-15))<tol) && i<maxi)||i<mini)
       nubefore=r0;
       v0before=v0;   
       [r0,v0]=EIF0(muI-w0,DI,Cm,gL,VT,Vre,EL,DeltaT,vs);
       w0=(1-di)*w0+di*(a*(v0-EL)+b*r0*tauw);    
       i=i+1;   
    end
end

if(i==maxi)
    warning('Fixed point iterator did not converge to desired tolerance.')
end


% Return density if requested
if(nargout==3)
   [~,~,P0]=EIF0ReturnP0(muI-w0,DI,Cm,gL,VT,Vre,EL,DeltaT,vs); 
end


end


