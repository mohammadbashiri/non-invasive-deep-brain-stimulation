% 
% [Sr,Sv]=EIF1M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs,freqs,p0);
% 
% Matlab version of EIF1.c  
% The C version is faster.
%
%  Computes the linear response of the firing rate, r1, and the mean
%  membrane potential, v1 of an EIF model neuron driven by additive noise.
%   
%  Neuron model is assumed to obey:
%    Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)+muI+sqrt(2*DI)*eta+perturbation
%  where eta is Gaussian white noise.
%  When V reaches threshold at Vth, it is reset instantly to Vre.
%  
%  freqs is a vector of frequencies over which the linear response is computed.
%  All frequencies are interpreted with units kHz. 
%  Frequency vectors should be positive and monotonically increasing.
%  
%  The membrane potential mesh is passed in the array, vs.
%  The last element of vs is assumed to be Vth and the first 
%  element (Vlb) should be small enough that 
%  the density is approximately zero there. A warning will be
%  issued if the density is not small at Vlb.
%
%  The steady state density, p0, should also be passed in.  It should
%  be the same length as vs.
%
% Uses threshold integration methods from:
%  
% Richardson, M.J.E. (2008). Spike-train spectra and network response 
% functions for non-linear integrate-and-fire neurons. Biological 
% Cybernetics, 99(4-5), 381-92.
% 
% with the modifications and extensions described in:
% 
% Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
% neuron models with stochastic inputs.  To appear.
%  
% Please cite these papers if you publish research that uses this code or some modification
% thereof.
%
% Author: Robert Rosenbaum
%

function [Sr,Sv]=EIF1M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,vs,freqs,p0)

numfreqs=numel(freqs);
Nv=numel(vs);

Sr=zeros(size(freqs));
Sv=zeros(size(freqs));

% Perform threshold integration at each frequency 
% The EIF0M.m code is better commented and very similar 
% to this code.  See there for more clarification. 
D0=(DI)/(Cm*Cm);
for i=1:numfreqs
    p1=0;
    pr=0;
    p1last=p1;
    prlast=pr;
    j1=0;
    jr=1;
    p1vint=0;
    prvint=0;
    flag=0;
    for k=(Nv-1):-1:1

        dv=vs(k+1)-vs(k);
        if(dv<=0)
           error('dv negative or too small.');
        end
        % Evaluate G, H1 and Hr and left endpoint 
        v=vs(k);    
        p00=p0(k);
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        A1=(1)/Cm;        
        Gleft=-A0/D0;
        H1left=(j1-A1*p00)/D0; 
        Hrleft=jr/D0;

        % Evaluate G, H1 and Hr and midpoint 
        v=(vs(k)+vs(k+1))/2.0;
        p00=(p0(k)+p0(k+1))/2.0;
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        A1=(1)/Cm;        
        Gmid=-A0/D0;
        H1mid=(j1-A1*p00)/D0; 
        Hrmid=jr/D0; 

        % Evaluate G, H1 and Hr and right endpoint 
        v=vs(k+1);
        p00=p0(k+1);
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        A1=(1)/Cm;        
        Gright=-A0/D0;
        H1right=(j1-A1*p00)/D0; 
        Hrright=jr/D0;

        % Simspon's approx to exponential of integral of G 
        expGint=exp((1.0/6.0)*(Gleft+4*Gmid+Gright)*dv);

        % Evaluate G halfway between left enpoint and midpoint 
        % For use in the line below 
        v=(vs(k+1)+3.0*vs(k))/4.0;
        p00=(p0(k+1)+3.0*p0(k+1))/4.0;
        A0=(-gL*(v-EL)+gL*DeltaT*exp((v-VT)/DeltaT)+muI)/Cm;
        A1=(1)/Cm;        
        Gmidmid=-A0/D0;       

        % Now estimate the integral of G from the left endpoint to the midpoint 
        expGint2=exp((1.0/6.0)*(Gleft+4.0*Gmidmid+Gmid)*(dv/2.0));

        % Estimate the integral of 
        % H*exp(Int G) over entire interval 
         H1expIntG=(1.0/6.0)*(H1left*1+4.0*H1mid*expGint2+H1right*expGint)*dv;
         HrexpIntG=(1.0/6.0)*(Hrleft*1+4.0*Hrmid*expGint2+Hrright*expGint)*dv;

         p1=p1*expGint+H1expIntG;
         pr=pr*expGint+HrexpIntG;

        j1=j1+2*pi*sqrt(-1)*freqs(i)*p1*dv;
        jr=jr+2*pi*sqrt(-1)*freqs(i)*pr*dv;

        if(flag==0 && v<=Vre)
            jr=jr-1;
            flag=1; 
        end

        % Trapezoidal approx to integral 
        p1vint=p1vint+((p1+p1last)/2)*v*dv;
        prvint=prvint+((pr+prlast)/2)*v*dv;

        p1last=p1;
        prlast=pr;

    end
    
    Sr(i)=-j1/jr;
    Sv(i)=p1vint+Sr(i)*prvint;
end




end

