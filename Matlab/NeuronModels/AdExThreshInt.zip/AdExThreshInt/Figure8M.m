
disp(sprintf('\nNOTICE: Using Matlab version of threshold integrator.\nSee README for instructions on using the faster, C, version.\n'));

% Set default parameter values
DefaultParams;

% Intensity of white noise perturbation
Dn=0.1;

% Fine mesh of frequencies
freqs=0:.0001:2;

% Coarse mesh of frequencies
freqsC=logspace(log10(freqs(2)),min(log10(max(freqs)),log10(.2)),30);



tic

% Get mean input and effective diffusion coefficient
% for matched variance approx.
muI=Je*re+Ji*ri;
DIstatic=(Je^2*re+Ji^2*ri)/2;
Deff=DIstatic*(1-(a/(a+gL))*(taum./(taum+tauw)));

% Compute steady-state stats
[r0,v0,P0]=AdEx0M(muI,Deff+Dn,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs);

% Compute linear response fcns
[Sr,~,SrC,~]=AdEx1M(muI,Deff+Dn,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs,freqs,freqsC,P0,r0);

% Get cross-spectral densities
% on fine and coarse freq meshes
Custilde=2*Dn*Sr;
CusCtilde=2*Dn*SrC;

% Invert Fourier transform to get cross-covariance
% taking the cojugate makes it Csu instead of 
% Cus.  This gives the STA through an inverse
% Fourier transform.
[taus,Csu]=CCGfromCrossSpec(freqs,conj(Custilde));

% STA is cross-covariance divided by rate
STA=Csu./r0;

% To correct gibbs phenomena, add the STA
% at positive lags (which should be zero) to 
% negative lags.  Then set pos lags to zero.
nSTA=numel(STA);
STA((nSTA-1)/2:-1:1)=STA((nSTA+3)/2:end)+STA((nSTA-1)/2:-1:1);
STA(1:(nSTA-1)/2)=0;
STA=STA(end:-1:1);
tSTA=toc;

% Display run time
disp(sprintf('Time to compute cross-spec and STA: %.2f ms',tSTA*1000))

% Plot results
figure
subplot(1,3,1)
freqInds=find(freqs<=.2 & freqs>.0002);
semilogx(1000*freqs(freqInds),abs(Custilde(freqInds)),'Color',[.2 .2 .9],'LineWidth',2)
axis tight
box off
set(gca,'LineWidth',2)
xlabel('freq (Hz)')
ylabel('abs(Cross-spec.)')
set(gca,'XTick',[1e0 1e1 1e2])
set(gca,'FontSize',12)

subplot(1,3,2)
freqInds=find(freqs<=.2 & freqs>.0002);
semilogx(1000*freqs(freqInds),angle(Custilde(freqInds)),'Color',[.2 .2 .9],'LineWidth',2)
axis tight
box off
set(gca,'LineWidth',2)
xlabel('freq (Hz)')
ylabel('angle(Cross-spec.)')
set(gca,'XTick',[1e0 1e1 1e2])
set(gca,'FontSize',12)

subplot(1,3,3)
maxtau=81;
plot(taus(abs(taus)<=maxtau),STA(abs(taus)<=maxtau),'Color',[.2 .2 .9],'LineWidth',2)
axis tight
box off
set(gca,'LineWidth',2)
xlabel('lag (ms)')
ylabel('STA')
set(gca,'XTick',[-80 -40 0 40 80])
set(gca,'FontSize',12)

% Re-size figure
temp=get(gcf,'Position');
temp(4)=temp(4)*.5;
temp(3)=temp(3)*1.5;
set(gcf,'Position',temp)

