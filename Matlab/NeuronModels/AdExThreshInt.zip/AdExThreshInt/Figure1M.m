

disp(sprintf('\nNOTICE: Using Matlab version of threshold integrator.\nSee README for instructions on using the faster, C, version.\n'));

% Set default parameter values
DefaultParams;

% Set rates
re=linspace(7,12,25);

% Mean input current
muI=Je*re+Ji*ri;

% Diffusion coefficient and firing rate
% for quasi-static approx.
DIstatic=(Je^2*re+Ji^2*ri)/2;
rateStatic=zeros(size(re));
for j=1:numel(re)
    [nu0,~]=AdEx0M(muI(j),DIstatic(j),Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs);
    rateStatic(j)=nu0;
end

% Diffusion coefficient and firing rate
% for matched var approx.
rateMatchedVar=zeros(size(re));
tic
Deff=DIstatic*(1-(a/(a+gL))*(taum./(taum+tauw)));
for j=1:numel(re)
    [nu0,~]=AdEx0M(muI(j),Deff(j),Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs);
    rateMatchedVar(j)=nu0; 

end
tMatchedVar=toc/numel(re);



% Display run time
disp(sprintf('Average time to compute each rate: %.2f ms',tMatchedVar*1000))

% Plot results
figure
plot(re,1000*rateMatchedVar,'Color',[.2 .2 .9],'LineWidth',2)
hold on
plot(re,1000*rateStatic,'Color',[.6 .6 .6],'LineWidth',2)
axis tight
box off
set(gca,'LineWidth',2)
xlabel('Exc. presyn. rate (kHz)')
ylabel('Postsyn. rate (Hz)')
set(gca,'XTick',[7 8 9 10 11 12])
set(gca,'YTick',[0 10 20 30 40 50])
h=legend('Quasi static','Match var','Location','Best');
legend boxoff
set(h,'FontSize',12)
set(gca,'FontSize',12)


