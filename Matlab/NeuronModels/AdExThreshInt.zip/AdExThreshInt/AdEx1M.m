%
% [Sr,Sv,SrC,SvC]=AdEx1M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs,freqs,freqsC,P0,r0);
% 
% Computes the linear response of the firing rate, Sr, and of the mean 
% membrane potential, Sv, of an AdEx model neuron driven by additive white
% noise with a perturbation
%
% Uses the Matlab EIF solvers,  EIF0M.c  and EIF1M.c  
% The C version is faster.  For the C version, use AdEx1.m instead
%
% freqs is a vector of frequencies with a finer mesh, freqsC is a vector
% of frequencies with a coarser mesh.  The lin. resp. fcns. are computed 
% directly on the coarser mesh, then interpolated to obtain the values on
% the finer mesh.  Likewise, Sr and Sv are evaluated at the finer mesh of
% frequencies and SrC, SvC at the coarser mesh.
%
% freqsC is an optional argument.  If it is not passed, a default coarse
% mesh is used.
%
% All frequencies are interpreted with units kHz. 
% Frequency vectors should be positive and monotonically increasing.
%   
%  Neuron model is assumed to obey:
%  Cm*V'=-gL*(V-EL)+gL*DeltaT*exp((V-VT)/DeltaT)-w+muI+sqrt(2*DI)*eta+perturbation
%  tauw*w'=-w+a*(V-EL)
%  where eta is Gaussian white noise.
%  When V reaches threshold at Vth, it is reset instantly to Vre
%  and w is incremented by b.
%
%  The membrane potential mesh is passed in the array, vs.
%  The last element of vs is assumed to be Vth and the first 
%  element (Vlb) should be small enough that 
%  the density is approximately zero there. A warning will be
%  issued if the density is not small at Vlb.
%
% P0 and r0 are optional arguments representing the steady-state membrane
% potential density and firing rate.  They can be computed from AdEx0.m
% If they're not passed, they will be computed here.
% Uses threshold integration methods from:
%  
% Richardson, M.J.E. (2008). Spike-train spectra and network response 
% functions for non-linear integrate-and-fire neurons. Biological 
% Cybernetics, 99(4-5), 381-92.
% 
% and fixed point iteration methods from:
%  
% Richardson, M. (2009). Dynamics of populations and networks of neurons with 
% voltage-activated and calcium-activated currents. Physical Review E, 80(2), 021928. 
% doi:10.1103/PhysRevE.80.021928
%  
% with the modifications and extensions described in:
% 
% Rosenbaum, R. (2016). A diffusion approximation and numerical methods for adaptive 
% neuron models with stochastic inputs.  To appear.
%  
% Please cite these papers if you publish research that uses this code or some modification
% thereof.
%
% Author: Robert Rosenbaum
%


function [Sr,Sv,SrC,SvC]=AdEx1M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs,freqs,freqsC,P0,r0)



% The interpolation function to use.
interpfun=@(xC,yC,x)(exp(pchip(log(xC),log(yC),log(x))));

% A frequency value of zero or near zero does not work well with
% the threshold-integraiton scheme.  Instead, pass a very small 
% frequency.
% Alternatively, one could compute the zero-frequency response by
% computing the gain using AdEx0.m
freqs=freqs(:)';
if(freqs(1)<1e-9)
    freqs=[min(freqs(2)/2,.00001) freqs(2:end)];
end

% Default coarse frequency mesh
if ~exist('freqsC','var') || isempty(freqsC)
    freqsC=(logspace(log10(freqs(2)),min(log10(max(freqs)),log10(.3)),50));
end

% Make it a row vector
freqsC=freqsC(:)';

% A frequency value of zero or near zero does not work well with
% the threshold-integraiton scheme.  Instead, pass a very small 
% frequency.
% Alternatively, one could compute the zero-frequency response by
% computing the gain using AdEx0.m
if(freqsC(1)<1e-9)
    warning('freqsC should not contain zero freq.  Replacing with low freq.')
    freqsC=[min(freqsC(2)/2,.00001) freqsC(2:end)];
end

% If r0 and P0 were not passed, compute them
if ~exist('r0','var') || ~exist('p0','var') || isempty(r0)|| isempty(P0)
    [r0,v0,P0]=AdEx0M(muI,DI,Cm,gL,VT,Vre,EL,DeltaT,tauw,a,b,vs);
end

% Steady state mean adaptation current
w0=(a*(v0-EL)+b*r0*tauw);

% Make it a column vector
vs=vs(:);

% Compute linear response of EIF with shifted mu on coarse mesh
[SrCEIF,SvCEIF]=EIF1M(muI-w0,DI,Cm,gL,VT,Vre,EL,DeltaT,vs,freqsC,P0);

% Compute linear response of the mean adaptation current
% on coarse mesh
SwrC=tauw*b./(2*pi*sqrt(-1)*freqsC*tauw+1);
SwvC=a./(2*pi*sqrt(-1)*freqsC*tauw+1);

% Now compute linear response of rate and mean membrane
% potential
SrC=SrCEIF./(1+SvCEIF.*SwvC+SrCEIF.*SwrC);
SvC=SvCEIF./(1+SrCEIF.*SwrC+SvCEIF.*SwvC);
SrC(1)=abs(SrC(1));
SvC(1)=abs(SvC(1));

% There are two ways to perform the interpolation
% We can interpolate the component functions, then
% compute the linear response from them.
% Or we can compute the final linear response on the coarser
% mesh then interpolate it.
% A quick comparison shows that the latter method is more
% reliable, but it might depend on parameters.

if(false) % Interp components, then compute lin resp
    SrEIF=interpfun(freqsC,SrC,freqs);
    SvEIF=interpfun(freqsC,SvC,freqs);
    Swr=tauw*b./(2*pi*sqrt(-1)*freqs*tauw+1);
    Swv=a./(2*pi*sqrt(-1)*freqs*tauw+1);
    Sr=SrEIF./(1+SvEIF.*Swv+SrEIF.*Swr);
    Sv=SvEIF./(1+SrEIF.*Swr+SvEIF.*Swv);
else % Interp lin resp directly (perhaps more reliable)
    Sr=interpfun(freqsC,SrC,freqs);
    Sv=interpfun(freqsC,SvC,freqs);
end

% The zero-frequency lin resp should be real, but threshold
% integration will give a small imaginary part.  We should
% get rid of that.  But only if the lowest frequency is less
% than 1 Hz.  Otherwise, maybe it wasn't intended to represent
% zero frequency.
if(freqs(1)<=.001)
  Sr(1)=abs(Sr(1));
  Sv(1)=abs(Sv(1));
end
if(freqsC(1)<=.001)
  SrC(1)=abs(SrC(1));
  SvC(1)=abs(SvC(1));
end

end
