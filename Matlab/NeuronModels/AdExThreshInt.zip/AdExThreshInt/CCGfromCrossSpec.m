% [taus,C]=CrossCovfromCrossSpec(f,Ctilde)
% Calcualtes cross-covariance from 
% one-sided cross Spectrum. 
% f are frequencies
% Ctilde is cross-spec
% taus are lags
% C is cross-cov
%
% Cross Spec is assumed one-sided
% so freqs must start at zero.
% Freqs must be evenly spaced.
% Cross-cov is two-sided.
%
% By James Trousdale and Robert Rosenbaum

function [taus,C]=CCGfromCrossSpec(f,Ctilde)

% Change freqs and cross-spec to two-sided
f=[-f(end:-1:2) f(1:end-1)];
Ctilde=[conj(Ctilde(end:-1:2)); Ctilde(1:end-1)]';

% Invert the one-sided Fourier transform
[taus,C]=Jifft(f,Ctilde);

% Get rid of imaginary components without 
% changing norm or sign of real part
%R=real(R);
C=sign(real(C)).*abs(C);

% Fill in last bin
taus(end+1)=-taus(1);
C(end+1)=C(1);

end
